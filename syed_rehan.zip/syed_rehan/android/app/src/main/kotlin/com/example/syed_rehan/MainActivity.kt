package com.example.syed_rehan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
